package com.acadgild.mr.practice;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class InvalidRecordFindReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
   @Override
protected void reduce(Text companyName, Iterable<IntWritable> values,
		Reducer<Text, IntWritable, Text, IntWritable>.Context context) throws IOException, InterruptedException {
         int sum=0;
         for(IntWritable val:values){
        	 sum=sum+val.get();
         }
         context.write(companyName, new IntWritable(sum));
   }
}
