package com.acadgild.mr.practice;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.util.StringUtils;

public class InvalidRecordFindMapper extends Mapper<LongWritable, Text, Text,IntWritable>{

	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, IntWritable>.Context context)
			throws IOException, InterruptedException {
	    String[] inputData=value.toString().split("\\|");
        if(inputData[0].equals("Onida")){ 
          if(!inputData[1].equals("NA")){
        	context.write(new Text(inputData[3]),new IntWritable(1));   	
        }}
        
	}
}
